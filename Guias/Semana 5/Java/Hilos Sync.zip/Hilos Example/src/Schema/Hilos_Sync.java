package Schema;

import java.util.ArrayList;

public class Hilos_Sync {
	
	private volatile static int global = 0;
	
	private static ArrayList<Thread> threads = new ArrayList<Thread>();
	
	
	
	public static void init() {
		
		for (int i = 0; i < 4; i++) {
			
			Thread thread = new Thread(new Runnable() {		
				@Override
				public void run() {
					doing();
				}

			});
			threads.add(thread);	
		}	
		runThreads();	
	}


	private static void runThreads() {
		
		for (int i = 0; i < threads.size(); i++) {
			threads.get(i).start();
			try {
				threads.get(i).sleep(0);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	public static void main(String[] args) {
		
		init();
		
		
	}
	
	private  static void incrementarGlobal() {
		global++;
	}
	
	public synchronized static void doing() {
		System.out.println("Init Thread number : " + global);
		switch (global) {
		case 0:
			for (int j = 0; j < 10; j++) {
				System.out.println("Thread Number :" + global + " say : " + j);
			}
			break;
		case 1:
			for (int j = 0; j < 10; j++) {
				if(j%2==0) {
					System.out.println("Thread Number :" + global + " say : " + j);
				}
			}
			break;
		case 2:
			for (int j = 0; j < 10; j++) {
				if(j%2!=0) {
					System.out.println("Thread Number :" + global + " say : " + j);

				}
			}
			break;
		case 3:
			for (int j = 0; j < 10; j++) {
				System.out.println("Thread Number :" + global + " say : " + j*3);
				
			}
			break;

		default:
			break;
		}
		incrementarGlobal();
	}

}
